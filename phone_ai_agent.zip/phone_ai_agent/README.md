# Phone AI Agent (Flutter — Android + iOS)

একটা কাস্টম-নামের AI এজেন্ট, যা চ্যাট/ভয়েসে কথা বলবে, অনলাইনে থাকলে AI API কল করবে, অফলাইনে বেসিক রেসপন্স দেবে, আর Android-এ অ্যাক্সেসিবিলিটি সার্ভিসের মাধ্যমে অন্য অ্যাপ কিছুটা নিয়ন্ত্রণ করতে পারবে।

## যা যা আছে এখানে
- `lib/main.dart` — মূল অ্যাপ, চ্যাট UI, এজেন্টের নাম সেট করার অপশন, কমান্ড চেনা
- `lib/services/ai_service.dart` — অনলাইন হলে Anthropic API কল, অফলাইন হলে fallback
- `lib/services/voice_service.dart` — স্পিচ-টু-টেক্সট ও টেক্সট-টু-স্পিচ
- `lib/services/wake_word_service.dart` — নাম ধরে ডাকলে সাড়া দেওয়ার (wake word) সার্ভিস
- `lib/services/app_control_service.dart` — Android অ্যাপ কন্ট্রোল কল করার Dart ব্রিজ
- `android_accessibility_service_sample/` — Android-এ অ্যাপ কন্ট্রোলের জন্য Kotlin কোড:
  - `AgentAccessibilityService.kt` — ইউটিউব খোলা/সার্চ/Like/Share
  - `MainActivity.kt` — Flutter ↔ Android যোগাযোগের ব্রিজ
  - `manifest_snippet.xml` — AndroidManifest.xml-এ যা যোগ করতে হবে

## নতুন ফিচার সেটআপ

### Wake word ("হে [নাম]" বললে সাড়া দেওয়া)
1. [console.picovoice.ai](https://console.picovoice.ai)-এ ফ্রি অ্যাকাউন্ট বানাও
2. সেখানে "Porcupine" সেকশনে গিয়ে তোমার এজেন্টের নাম (যেমন "মিত্র") দিয়ে একটা কাস্টম wake word ট্রেইন করো — কয়েক মিনিট লাগে, একটা `.ppn` ফাইল ডাউনলোড হবে
3. সেই ফাইল `assets/wake_word/` ফোল্ডারে রাখো এবং `pubspec.yaml`-এ assets হিসেবে যোগ করো
4. `WakeWordService` কে তোমার Access Key ও `.ppn` ফাইলের পাথ দিয়ে init করো (main.dart-এ)
- **নাম বদলালে** নতুন করে আবার ট্রেইন করতে হবে — এটা এই প্রযুক্তির সীমাবদ্ধতা

### YouTube কন্ট্রোল (খোলা, সার্চ, Like, Share) — শুধু Android
1. `MainActivity.kt` ও `AgentAccessibilityService.kt` তোমার Android প্রজেক্টে বসাও (আগের ধাপে বলা জায়গায়)
2. অ্যাপ চালিয়ে প্রথমবার ইউটিউব/লাইক/শেয়ার বললে অ্যাপ নিজেই Accessibility Settings খুলে দেবে — সেখানে ম্যানুয়ালি "Phone AI Agent" চালু করে দিতে হবে (এটা Android নিজে থেকে চালু করতে দেয় না, নিরাপত্তার কারণে)
3. এরপর "ইউটিউব খোলো", "এটা লাইক করো", "শেয়ার করো" বললে কাজ করবে
- **শুধু একবার-একবার অ্যাকশন** — বারবার/শিডিউলড Like-Share অটোমেশন ইচ্ছাকৃতভাবে রাখা হয়নি, কারণ এটা YouTube-এর নিয়মবিরুদ্ধ হতে পারে

### Google Photos-এ ছবি খোঁজা
⚠️ **জেনে রাখা জরুরি**: Google ২০২৫ সালে তাদের Photos API সীমিত করে দিয়েছে — কোনো অ্যাপ এখন আর প্রোগ্রামেটিকভাবে সরাসরি "আমার ছবি থেকে X খুঁজে দাও" করতে পারে না অফিসিয়ালভাবে। Google-এর নিজস্ব Picker API-তে ইউজারকে নিজে হাতেই ছবি বাছতে হয়।

তাই এখানে একটা ঘুরপথ (workaround) ব্যবহার করা হয়েছে: Google Photos অ্যাপ খুলে, ওর নিজের সার্চ বক্সে টাইপ করে দেওয়া হয় (Google Photos-এর নিজস্ব AI সার্চ তখন কাজ করে)। এটা:
- Accessibility Service-নির্ভর, তাই আগের ধাপে যেভাবে Accessibility চালু করেছ সেটাই যথেষ্ট, আলাদা সেটআপ লাগবে না
- **ভঙ্গুর** — Google Photos অ্যাপ আপডেট হলে বাটনের নাম/জায়গা বদলে গেলে কাজ নাও করতে পারে; `AgentAccessibilityService.kt`-এর `tapSearchAndType` ফাংশনে গিয়ে "search" শব্দটা বদলে দেখতে হতে পারে
- সার্চ বক্সে লেখাটা বসিয়ে দেয়, কিন্তু অনেক ফোনে সাবমিট করতে কিবোর্ডের সার্চ বাটনে একবার নিজে চাপ দিতে হতে পারে

## সীমাবদ্ধতা (গুরুত্বপূর্ণ)
- **iOS**: Apple অন্য অ্যাপ কন্ট্রোল করার অনুমতি দেয় না। iOS ভার্সনে শুধু চ্যাট/ভয়েস অ্যাসিস্ট্যান্ট হিসেবে কাজ করবে, প্লাস App Intents/Shortcuts দিয়ে সীমিত অ্যাকশন (যেমন: "টাইমার সেট করো", "মেসেজ পাঠাও")।
- **Android**: Accessibility Service ব্যবহার করলে Play Store-এ পাবলিশ করার সময় Google-এর কড়া রিভিউ পার হতে হয় (privacy policy, video demo লাগে) — কারণ এটা sensitive permission।
- **অফলাইন AI**: সত্যিকারের "স্মার্ট" অফলাইন AI (যেমন ছোট local LLM, যেমন Gemma/Phi) ফোনে চালাতে গেলে অ্যাপের সাইজ বড় হবে (১-৪ GB+) এবং পারফরম্যান্স ফোনের হার্ডওয়্যারের উপর নির্ভর করবে। এই স্কেলিটনে অফলাইন মোডে rule-based সাধারণ রেসপন্স রাখা হয়েছে — চাইলে পরে `tflite` বা `llama.cpp` দিয়ে আসল local model যোগ করা যায়।

## সেটআপ
1. [Flutter ইনস্টল করো](https://docs.flutter.dev/get-started/install)
2. এই ফোল্ডারে গিয়ে:
   ```
   flutter pub get
   ```
3. `lib/services/ai_service.dart`-এ তোমার API key বসাও (কখনো hardcode করে পাবলিক রিপোতে দিও না — production-এ backend proxy ব্যবহার করো)
4. চালাও:
   ```
   flutter run
   ```

## পরের ধাপ (তুমি যোগ করবে)
- এজেন্টের কাস্টম নাম ও পার্সোনালিটি সেভ করার জন্য `shared_preferences`
- Android Accessibility Service-কে Flutter-এর সাথে MethodChannel দিয়ে কানেক্ট করা
- ওয়েক ওয়ার্ড ("হে [নাম]") ডিটেকশনের জন্য `porcupine` বা `picovoice`

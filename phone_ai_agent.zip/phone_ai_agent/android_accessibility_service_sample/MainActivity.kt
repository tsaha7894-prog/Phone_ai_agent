package com.example.phone_ai_agent

import android.content.Intent
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "phone_ai_agent/app_control"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            val service = AgentAccessibilityService.instance

            when (call.method) {
                "isServiceEnabled" -> {
                    result.success(service != null)
                }
                "openAccessibilitySettings" -> {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    result.success(null)
                }
                "openYoutube" -> {
                    service?.openYoutube()
                    result.success(null)
                }
                "searchYoutube" -> {
                    val query = call.argument<String>("query") ?: ""
                    service?.searchYoutube(query)
                    result.success(null)
                }
                "likeCurrentVideo" -> {
                    result.success(service?.likeCurrentVideo() ?: false)
                }
                "shareCurrentVideo" -> {
                    result.success(service?.shareCurrentVideo() ?: false)
                }
                "searchGooglePhotos" -> {
                    val query = call.argument<String>("query") ?: ""
                    service?.searchGooglePhotos(query)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}

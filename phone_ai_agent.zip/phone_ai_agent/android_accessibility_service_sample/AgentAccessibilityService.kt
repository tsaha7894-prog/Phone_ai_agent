package com.example.phone_ai_agent

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * এই সার্ভিসটা চালু হলে (ইউজার Settings > Accessibility থেকে ON করলে)
 * এটা স্ক্রিনে কী দেখা যাচ্ছে সেটা পড়তে পারবে এবং বাটন ট্যাপ/টেক্সট
 * লেখার মতো অ্যাকশন চালাতে পারবে।
 *
 * ⚠️ Play Store-এ পাবলিশ করতে গেলে Google-কে accessibility declaration
 * ফর্ম + ভিডিও ডেমো দেখাতে হবে। ব্যক্তিগত ব্যবহারের জন্য (sideload) সমস্যা নেই।
 *
 * ⚠️ এই ফাংশনগুলো "ইউজার একবার বললে একবার করা"র জন্য বানানো —
 * বারবার/অটোমেটিক Like-Share স্প্যাম করা YouTube-এর নিয়মবিরুদ্ধ, তাই
 * এমন লুপ/শিডিউলড অটোমেশন এখানে রাখা হয়নি।
 */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        // MainActivity থেকে এই instance টা অ্যাক্সেস করা হবে
        var instance: AgentAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // স্ক্রিন পরিবর্তনের ইভেন্ট এখানে আসে; দরকার হলে লগ/প্রসেস করা যাবে
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /** ইউটিউব অ্যাপ খোলা */
    fun openYoutube() {
        val intent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent != null) startActivity(intent)
    }

    /** ইউটিউবে সার্চ করা (ইউটিউবের সার্চ ডিপ-লিংক ব্যবহার করে) */
    fun searchYoutube(query: String) {
        val intent = Intent(Intent.ACTION_SEARCH)
        intent.setPackage("com.google.android.youtube")
        intent.putExtra("query", query)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // ফলব্যাক: সরাসরি সার্চ URL খুলে দেওয়া
            val webIntent = Intent(Intent.ACTION_VIEW)
            webIntent.data = android.net.Uri.parse(
                "https://www.youtube.com/results?search_query=${android.net.Uri.encode(query)}"
            )
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(webIntent)
        }
    }

    /** বর্তমান স্ক্রিনে "Like" লেখা/বর্ণনার বাটন খুঁজে ক্লিক করা */
    fun likeCurrentVideo(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByDescriptionContains(root, "like") ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** বর্তমান স্ক্রিনে "Share" বাটন খুঁজে ক্লিক করা (শেয়ার মেনু খুলবে,
     *  এরপর কার সাথে শেয়ার করবে সেটা ইউজারকেই বেছে দিতে হবে) */
    fun shareCurrentVideo(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByDescriptionContains(root, "share") ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Google Photos খুলে, ওর নিজের সার্চ বক্সে [query] টাইপ করে দেয় —
     * এতে Google Photos-এর নিজস্ব AI-চালিত ছবি-সার্চ (যেমন "সমুদ্র",
     * "জন্মদিন") কাজ করবে এবং ফলাফল দেখাবে। ⚠️ Google Photos অ্যাপ
     * আপডেট হলে বাটনের contentDescription বদলে গেলে এটা কাজ নাও করতে
     * পারে — তখন নিচের "search"/"অনুসন্ধান" শব্দটা বদলে দেখতে হবে।
     */
    fun searchGooglePhotos(query: String) {
        val intent = packageManager.getLaunchIntentForPackage("com.google.android.apps.photos")
        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent == null) return
        startActivity(intent)

        // অ্যাপটা লোড হতে একটু সময় লাগে, তাই সামান্য অপেক্ষা করে তারপর
        // সার্চ বক্স খোঁজা হচ্ছে। ফোন/নেট স্লো হলে এই সময় বাড়াতে হতে পারে।
        Handler(Looper.getMainLooper()).postDelayed({
            tapSearchAndType(query, attemptsLeft = 5)
        }, 1200)
    }

    private fun tapSearchAndType(query: String, attemptsLeft: Int) {
        val root = rootInActiveWindow
        if (root == null || attemptsLeft <= 0) return

        // প্রথমে সার্চ আইকনে ট্যাপ করার চেষ্টা (অনেক সময় সরাসরি একটা
        // এডিটেবল সার্চ ফিল্ডও থাকে)
        val searchIcon = findNodeByDescriptionContains(root, "search")
        val editableField = findEditableNode(root)

        if (editableField != null) {
            setNodeText(editableField, query)
        } else if (searchIcon != null) {
            searchIcon.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            // ক্লিক করার পর ফিল্ড খুলতে সময় লাগে, তাই আবার চেষ্টা
            Handler(Looper.getMainLooper()).postDelayed({
                tapSearchAndType(query, attemptsLeft - 1)
            }, 600)
        }
    }

    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findEditableNode(child)
            if (result != null) return result
        }
        return null
    }

    private fun setNodeText(node: AccessibilityNodeInfo, text: String) {
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        // অনেক ফোনে টেক্সট সেট করার পর এন্টার/সার্চ অ্যাকশন লাগে —
        // এটা keyboard-নির্ভর, তাই সবসময় স্বয়ংক্রিয়ভাবে সাবমিট নাও হতে পারে।
        // প্রয়োজনে ইউজারকে keyboard-এর সার্চ বাটনে একবার চাপ দিতে হতে পারে।
    }

    fun clickNodeWithText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, text) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNodeByText(
        node: AccessibilityNodeInfo,
        text: String
    ): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByText(child, text)
            if (result != null) return result
        }
        return null
    }

    /** YouTube-এর Like/Share বাটনে সাধারণত visible টেক্সট থাকে না,
     *  তাই contentDescription (accessibility label) দিয়ে খোঁজা হয় */
    private fun findNodeByDescriptionContains(
        node: AccessibilityNodeInfo,
        keyword: String
    ): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (desc.contains(keyword.lowercase())) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByDescriptionContains(child, keyword)
            if (result != null) return result
        }
        return null
    }
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/ai_service.dart';
import 'services/voice_service.dart';
import 'services/app_control_service.dart';

void main() {
  runApp(const PhoneAiAgentApp());
}

class PhoneAiAgentApp extends StatelessWidget {
  const PhoneAiAgentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Phone AI Agent',
      theme: ThemeData(primarySwatch: Colors.indigo, useMaterial3: true),
      home: const AgentHomePage(),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  ChatMessage(this.text, this.isUser);
}

class AgentHomePage extends StatefulWidget {
  const AgentHomePage({super.key});
  @override
  State<AgentHomePage> createState() => _AgentHomePageState();
}

class _AgentHomePageState extends State<AgentHomePage> {
  final AiService _ai = AiService();
  final VoiceService _voice = VoiceService();
  final AppControlService _appControl = AppControlService();
  final TextEditingController _inputController = TextEditingController();
  final List<ChatMessage> _messages = [];

  String _agentName = "মিত্র"; // ডিফল্ট নাম — ইউজার বদলাতে পারবে
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _loadAgentName();
    _voice.init();
  }

  Future<void> _loadAgentName() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _agentName = prefs.getString('agent_name') ?? _agentName;
    });
  }

  Future<void> _saveAgentName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('agent_name', name);
    setState(() => _agentName = name);
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;
    setState(() {
      _messages.add(ChatMessage(text, true));
      _isTyping = true;
    });
    _inputController.clear();

    // আগে দেখা হচ্ছে এটা কোনো অ্যাপ-কন্ট্রোল কমান্ড কিনা।
    // মিলে গেলে সরাসরি সেই অ্যাকশন চালানো হয়, AI কল লাগে না।
    final handled = await _tryHandleAppCommand(text);
    if (handled != null) {
      setState(() {
        _messages.add(ChatMessage(handled, false));
        _isTyping = false;
      });
      await _voice.speak(handled);
      return;
    }

    final reply = await _ai.getResponse(text, _agentName);

    setState(() {
      _messages.add(ChatMessage(reply, false));
      _isTyping = false;
    });
    await _voice.speak(reply);
  }

  /// খুব সাধারণ keyword-ভিত্তিক কমান্ড চেনা।
  /// আরও ভালো করতে চাইলে এখানে AI দিয়ে intent detect করানো যাবে।
  Future<String?> _tryHandleAppCommand(String text) async {
    final t = text.toLowerCase();

    final enabled = await _appControl.isAccessibilityServiceEnabled();
    if (!enabled &&
        (t.contains("ইউটিউব") || t.contains("youtube") ||
         t.contains("লাইক") || t.contains("শেয়ার") ||
         t.contains("ছবি") || t.contains("ফটো"))) {
      await _appControl.openAccessibilitySettings();
      return "$_agentName: অ্যাপ কন্ট্রোল করতে হলে আগে Accessibility পারমিশন "
          "চালু করে দাও — সেটিংস খুলে দিচ্ছি।";
    }

    if (t.contains("ইউটিউব") && (t.contains("সার্চ") || t.contains("খুঁজ"))) {
      final query = text.replaceAll(RegExp(r'(ইউটিউব|সার্চ|খুঁজ|করো|কর)'), '').trim();
      await _appControl.searchYoutube(query.isEmpty ? text : query);
      return "$_agentName: ইউটিউবে \"$query\" সার্চ করে দিলাম।";
    }
    if (t.contains("ইউটিউব")) {
      await _appControl.openYoutube();
      return "$_agentName: ইউটিউব খুলে দিলাম।";
    }
    if (t.contains("ছবি") || t.contains("ফটো")) {
      final query = text
          .replaceAll(RegExp(r'(ছবি|ফটো|গুগল|খুঁজ|খোঁজ|করো|কর|দাও|দিয়ে)'), '')
          .trim();
      await _appControl.searchGooglePhotos(query.isEmpty ? text : query);
      return "$_agentName: গুগল ফটো খুলে \"$query\" সার্চ করে দিলাম। "
          "কিবোর্ডের সার্চ বাটনে একবার চাপ দিলেই ফলাফল দেখাবে।";
    }
    if (t.contains("লাইক")) {
      final ok = await _appControl.likeCurrentVideo();
      return ok
          ? "$_agentName: লাইক করে দিলাম।"
          : "$_agentName: Like বাটন খুঁজে পেলাম না — ভিডিওটা খোলা আছে তো?";
    }
    if (t.contains("শেয়ার")) {
      final ok = await _appControl.shareCurrentVideo();
      return ok
          ? "$_agentName: শেয়ার মেনু খুলে দিলাম, এখন কাকে পাঠাবে বেছে নাও।"
          : "$_agentName: Share বাটন খুঁজে পেলাম না — ভিডিওটা খোলা আছে তো?";
    }

    return null; // কোনো কমান্ড মিলল না, সাধারণ AI চ্যাট হিসেবে পাঠাও
  }

  void _renameAgentDialog() {
    final controller = TextEditingController(text: _agentName);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("এজেন্টের নাম দাও"),
        content: TextField(controller: controller),
        actions: [
          TextButton(
            onPressed: () {
              _saveAgentName(controller.text.trim());
              Navigator.pop(context);
            },
            child: const Text("সেভ করো"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_agentName),
        actions: [
          IconButton(icon: const Icon(Icons.edit), onPressed: _renameAgentDialog),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (context, i) {
                final m = _messages[i];
                return Align(
                  alignment: m.isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: m.isUser ? Colors.indigo[100] : Colors.grey[200],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(m.text),
                  ),
                );
              },
            ),
          ),
          if (_isTyping) const Padding(
            padding: EdgeInsets.all(8),
            child: Text("লিখছে..."),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.mic),
                  onPressed: () => _voice.startListening((text) {
                    _inputController.text = text;
                  }),
                ),
                Expanded(
                  child: TextField(
                    controller: _inputController,
                    decoration: const InputDecoration(hintText: "কিছু লেখো..."),
                    onSubmitted: _sendMessage,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () => _sendMessage(_inputController.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

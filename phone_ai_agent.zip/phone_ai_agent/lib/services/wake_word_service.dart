import 'package:porcupine_flutter/porcupine_manager.dart';
import 'package:porcupine_flutter/porcupine_error.dart';

/// এজেন্টের নাম ধরে ডাকলে ("হে [নাম]") সাড়া দেওয়ার জন্য।
///
/// ⚠️ গুরুত্বপূর্ণ সীমাবদ্ধতা:
/// Porcupine (wake word engine) কে একটা নির্দিষ্ট শব্দ চিনতে হলে
/// সেই শব্দের জন্য আগে থেকে ট্রেইন করা একটা .ppn ফাইল লাগে।
/// এজেন্টের নাম যেহেতু ইউজার নিজের ইচ্ছামতো বদলাতে পারে,
/// প্রতিটা সম্ভাব্য নামের জন্য আলাদা ট্রেনিং করা সম্ভব না।
///
/// তাই দুটো রাস্তা:
/// ১. Picovoice Console (console.picovoice.ai) এ গিয়ে ফ্রি অ্যাকাউন্ট
///    বানিয়ে একটা নির্দিষ্ট নাম (যেমন "মিত্র") এর জন্য .ppn ফাইল
///    ট্রেইন করে নাও (কয়েক মিনিট লাগে), সেটা assets/ এ রাখো।
///    এভাবে নাম বদলালে নতুন করে ট্রেইন করতে হবে।
/// ২. অথবা Porcupine এর বিল্ট-ইন কিছু wake word ব্যবহার করো
///    (যেমন "Jarvis", "Computer", "Hey Barista") — এগুলো ট্রেনিং
///    ছাড়াই পাওয়া যায়, কিন্তু বাংলা নাম কাস্টমাইজ করা যাবে না।
class WakeWordService {
  PorcupineManager? _porcupineManager;

  /// [accessKey] — Picovoice Console থেকে ফ্রি পাবে
  /// [keywordPath] — তোমার ট্রেইন করা .ppn ফাইলের পাথ (assets এ রেখে bundle করবে)
  Future<void> init({
    required String accessKey,
    required String keywordPath,
    required Function() onWakeWordDetected,
  }) async {
    try {
      _porcupineManager = await PorcupineManager.fromKeywordPaths(
        accessKey,
        [keywordPath],
        (keywordIndex) {
          onWakeWordDetected();
        },
      );
    } on PorcupineException catch (e) {
      throw Exception("Wake word ইঞ্জিন চালু করা যায়নি: ${e.message}");
    }
  }

  Future<void> start() async {
    await _porcupineManager?.start();
  }

  Future<void> stop() async {
    await _porcupineManager?.stop();
  }

  Future<void> dispose() async {
    await _porcupineManager?.delete();
  }
}

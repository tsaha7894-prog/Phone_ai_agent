import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

/// ভয়েস ইনপুট (শোনা) ও আউটপুট (বলা) হ্যান্ডেল করে।
/// এটা মোবাইলের নিজস্ব offline STT/TTS ইঞ্জিন ব্যবহার করে,
/// তাই ইন্টারনেট ছাড়াও কাজ করে (ফোনের ভাষা সাপোর্টের উপর নির্ভর করে)।
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _isListening = false;

  Future<bool> init() async {
    final available = await _speech.initialize();
    await _tts.setLanguage("bn-BD"); // দরকার হলে "en-US" এ বদলাও
    await _tts.setSpeechRate(0.5);
    return available;
  }

  Future<void> startListening(Function(String) onResult) async {
    if (_isListening) return;
    _isListening = true;
    await _speech.listen(
      onResult: (result) {
        onResult(result.recognizedWords);
      },
    );
  }

  Future<void> stopListening() async {
    _isListening = false;
    await _speech.stop();
  }

  Future<void> speak(String text) async {
    await _tts.speak(text);
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:connectivity_plus/connectivity_plus.dart';

/// এজেন্টের "মস্তিষ্ক"। অনলাইনে থাকলে AI API কল করে,
/// অফলাইনে সাধারণ rule-based রেসপন্স দেয়।
class AiService {
  // ⚠️ প্রোডাকশনে API key এখানে hardcode কোরো না।
  // নিজের ব্যাকএন্ড সার্ভার বানিয়ে সেখান থেকে কল করাই নিরাপদ।
  static const String _apiKey = "YOUR_API_KEY_HERE";
  static const String _apiUrl = "https://api.anthropic.com/v1/messages";

  Future<bool> _isOnline() async {
    final result = await Connectivity().checkConnectivity();
    return result != ConnectivityResult.none;
  }

  Future<String> getResponse(String userInput, String agentName) async {
    final online = await _isOnline();

    if (online) {
      try {
        return await _callOnlineAi(userInput, agentName);
      } catch (e) {
        return _offlineFallback(userInput, agentName);
      }
    } else {
      return _offlineFallback(userInput, agentName);
    }
  }

  Future<String> _callOnlineAi(String userInput, String agentName) async {
    final response = await http.post(
      Uri.parse(_apiUrl),
      headers: {
        "Content-Type": "application/json",
        "x-api-key": _apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: jsonEncode({
        "model": "claude-sonnet-4-6",
        "max_tokens": 500,
        "system":
            "তুমি \"$agentName\" নামের একটা ফোন AI এজেন্ট। সংক্ষিপ্ত ও সহায়ক উত্তর দাও।",
        "messages": [
          {"role": "user", "content": userInput}
        ],
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final content = data["content"] as List;
      return content
          .where((c) => c["type"] == "text")
          .map((c) => c["text"] as String)
          .join("\n");
    } else {
      throw Exception("API error: ${response.statusCode}");
    }
  }

  /// অফলাইন মোড — বেসিক rule-based রেসপন্স।
  /// পরে চাইলে এখানে on-device local model (tflite / llama.cpp) বসানো যাবে।
  String _offlineFallback(String userInput, String agentName) {
    final input = userInput.toLowerCase();

    if (input.contains("সময়") || input.contains("time")) {
      return "$agentName: এখন সময় ${DateTime.now().hour}:${DateTime.now().minute}";
    }
    if (input.contains("হাই") || input.contains("hi") || input.contains("hello")) {
      return "$agentName: হাই! আমি এখন অফলাইনে সীমিতভাবে কাজ করছি।";
    }
    return "$agentName: এখন ইন্টারনেট নেই, তাই পুরোপুরি স্মার্ট উত্তর দিতে পারছি না। "
        "নেট কানেক্ট হলে আরও ভালোভাবে সাহায্য করতে পারব।";
  }
}

import 'package:flutter/services.dart';

/// Flutter (Dart) থেকে Android-এর Accessibility Service কে কমান্ড পাঠানোর
/// জন্য MethodChannel ব্রিজ। iOS-এ এই ফিচারগুলো কাজ করবে না
/// (কারণ Apple অন্য অ্যাপ কন্ট্রোল করার অনুমতি দেয় না)।
class AppControlService {
  static const _channel = MethodChannel('phone_ai_agent/app_control');

  Future<bool> isAccessibilityServiceEnabled() async {
    try {
      return await _channel.invokeMethod('isServiceEnabled');
    } catch (_) {
      return false;
    }
  }

  Future<void> openAccessibilitySettings() async {
    await _channel.invokeMethod('openAccessibilitySettings');
  }

  /// ইউটিউব খুলে দেয়
  Future<void> openYoutube() async {
    await _channel.invokeMethod('openYoutube');
  }

  /// ইউটিউবে কিছু সার্চ করে
  Future<void> searchYoutube(String query) async {
    await _channel.invokeMethod('searchYoutube', {"query": query});
  }

  /// বর্তমানে খোলা ভিডিওতে Like বাটনে চাপ দেয়
  Future<bool> likeCurrentVideo() async {
    return await _channel.invokeMethod('likeCurrentVideo');
  }

  /// বর্তমানে খোলা ভিডিওর Share মেনু খোলে
  Future<bool> shareCurrentVideo() async {
    return await _channel.invokeMethod('shareCurrentVideo');
  }

  /// Google Photos খুলে ওর নিজের সার্চ বক্সে query টাইপ করে দেয়।
  /// এটা Google-এর নিজস্ব API না, Accessibility দিয়ে করা একটা
  /// ঘুরপথ — তাই মাঝেমধ্যে ম্যানুয়ালি keyboard-এর search বাটনে
  /// চাপ দিতে হতে পারে সাবমিট করার জন্য।
  Future<void> searchGooglePhotos(String query) async {
    await _channel.invokeMethod('searchGooglePhotos', {"query": query});
  }
}
